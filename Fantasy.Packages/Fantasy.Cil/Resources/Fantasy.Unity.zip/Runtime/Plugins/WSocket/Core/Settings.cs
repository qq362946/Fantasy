﻿namespace UnityWebSocket
{
    public static class Settings
    {
        public const string GITHUB = "https://github.com/psygames/UnityWebSocket";
        public const string QQ_GROUP = "1126457634";
        public const string QQ_GROUP_LINK = "https://qm.qq.com/cgi-bin/qm/qr?k=KcexYJ9aYwogFXbj2aN0XHH5b2G7ICmd";
        public const string EMAIL = "799329256@qq.com";
        public const string AUHTOR = "psygames";
        public const string VERSION = "2.8.6";
    }
}
