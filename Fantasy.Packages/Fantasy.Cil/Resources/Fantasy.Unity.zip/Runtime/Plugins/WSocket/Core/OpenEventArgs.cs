using System;

namespace UnityWebSocket
{
    public class OpenEventArgs : EventArgs
    {
        internal OpenEventArgs()
        {
        }
    }
}
