﻿using System.Runtime.CompilerServices;

namespace LightProto
{
    public static class Extensions { }
}
