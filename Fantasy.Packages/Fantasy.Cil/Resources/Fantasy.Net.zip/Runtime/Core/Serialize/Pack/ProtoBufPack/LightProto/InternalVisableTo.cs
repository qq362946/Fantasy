﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("LightProto.Google")]
